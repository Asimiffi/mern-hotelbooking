import React from "react";
const Error = () => {
  return (
    <div>
      <div class="alert alert-danger" role="alert">
        Something went wrong, please try again later
      </div>
    </div>
  );
};

export default Error;
