import React from "react";
const Error = () => {
  return (
    <div>
      <div class="alert alert-danger" role="alert">
        Invalid Login Credentials
      </div>
    </div>
  );
};

export default Error;
