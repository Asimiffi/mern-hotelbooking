import React from 'react'

const success = () => {
  return (
    <div><div class="alert alert-success" role="alert">
    successfully cancelled
  </div></div>
  )
}

export default success